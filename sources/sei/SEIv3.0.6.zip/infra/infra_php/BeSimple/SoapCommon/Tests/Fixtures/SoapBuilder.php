<?php

namespace BeSimple\SoapCommon\Tests\Fixtures;

use BeSimple\SoapCommon\AbstractSoapBuilder;

class SoapBuilder extends AbstractSoapBuilder
{
}
