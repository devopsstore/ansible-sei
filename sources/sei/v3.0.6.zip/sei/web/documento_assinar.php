<?
/*
* TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
*
* 15/09/2008 - criado por marcio_db
*
*
*/

try {
  require_once dirname(__FILE__).'/SEI.php';

  session_start();

  //////////////////////////////////////////////////////////////////////////////
  InfraDebug::getInstance()->setBolLigado(false);
  InfraDebug::getInstance()->setBolDebugInfra(true);
  InfraDebug::getInstance()->limpar();
  //////////////////////////////////////////////////////////////////////////////

  SessaoSEI::getInstance()->validarLink();
  
  SessaoSEI::getInstance()->validarPermissao($_GET['acao']);
	
  //PaginaSEI::getInstance()->salvarCamposPost(array('selCargoFuncao'));
  
  PaginaSEI::getInstance()->setTipoPagina(InfraPagina::$TIPO_PAGINA_SIMPLES);
  
  $strParametros = '';
  if(isset($_GET['arvore'])){
    $strParametros .= '&arvore='.$_GET['arvore'];
  }

  if (isset($_GET['id_procedimento'])){
    $strParametros .= '&id_procedimento='.$_GET['id_procedimento'];
  }
  
  if (isset($_GET['id_documento'])){
    $strParametros .= '&id_documento='.$_GET['id_documento'];
  }
  
  if (isset($_GET['id_bloco'])){
    $strParametros .= '&id_bloco='.$_GET['id_bloco'];
  }
  
  $bolAssinaturaOK = false;
  $bolPermiteAssinaturaLogin=false;
  $bolPermiteAssinaturaCertificado=false;
  $bolAutenticacao = false;

  switch($_GET['acao']){
    
    case 'documento_assinar':

      $objInfraParametro=new InfraParametro(BancoSEI::getInstance());
      $tipoAssinatura=$objInfraParametro->getValor('SEI_TIPO_ASSINATURA_INTERNA');

      $strTitulo = 'Assinatura de Documento';            
      if ($_GET['acao_origem']=='bloco_assinatura_listar'){

        $objRelBlocoProtocoloDTO = new RelBlocoProtocoloDTO();
        $objRelBlocoProtocoloDTO->setNumIdBloco($_GET['id_bloco']);
        $objRelBlocoProtocoloDTO->setOrdNumSequencia(InfraDTO::$TIPO_ORDENACAO_ASC);

        $objRelBlocoProtocoloRN = new RelBlocoProtocoloRN();
        $arrIdDocumentos = InfraArray::converterArrInfraDTO($objRelBlocoProtocoloRN->listarProtocolosBloco($objRelBlocoProtocoloDTO),'IdProtocolo');
        $strAncora = $_GET['id_bloco'];

      }else if ($_GET['acao_origem']=='rel_bloco_protocolo_listar'){                                              
        
        $arrIdDocumentos = array();
        $arrIdDocumentoBloco = PaginaSEI::getInstance()->getArrStrItensSelecionados();
        
        foreach($arrIdDocumentoBloco as $idDocumentoBloco){
          $arrTemp = explode('-',$idDocumentoBloco);
          $arrIdDocumentos[] = $arrTemp[0];
        }                     
        $strAncora = implode(',',$arrIdDocumentoBloco);

      }else if ($_GET['acao_origem']=='arvore_visualizar' || $_GET['acao_origem']=='bloco_navegar' || $_GET['acao_origem']=='editor_montar'){

        $arrIdDocumentos = array($_GET['id_documento']);
        $strAncora = $_GET['id_documento'];

      }else{

        if (!isset($_POST['hdnIdDocumentos'])){
          throw new InfraException('Nenhum documento informado.');
        }

        if ($_GET['hash_documentos'] != md5($_POST['hdnIdDocumentos'])){
          throw new InfraException('Conjunto de documentos inv�lido.');
        }

        $arrIdDocumentos = explode(',',$_POST['hdnIdDocumentos']);
        $strAncora = $_POST['hdnAncora'];
      }

      $numRegistros = count($arrIdDocumentos);

      if ($numRegistros==1){
        $objDocumentoDTO = new DocumentoDTO();
        $objDocumentoDTO->retStrStaDocumento();
        $objDocumentoDTO->retNumIdTipoConferencia();
        $objDocumentoDTO->setDblIdDocumento($arrIdDocumentos[0]);

        $objDocumentoRN = new DocumentoRN();
        $objDocumentoDTO = $objDocumentoRN->consultarRN0005($objDocumentoDTO);

        if ($objDocumentoDTO!=null && $objDocumentoDTO->getStrStaDocumento()==DocumentoRN::$TD_EXTERNO){
          $strTitulo = 'Autentica��o de Documento';
          $tipoAssinatura=$objInfraParametro->getValor('SEI_TIPO_AUTENTICACAO_INTERNA');
          $bolAutenticacao = true;
        }
      }

      switch ($tipoAssinatura){
        case 1:
          $bolPermiteAssinaturaCertificado=true;
          $bolPermiteAssinaturaLogin=true;
          break;
        case 2:
          $bolPermiteAssinaturaLogin=true;
          break;
        case 3:
          $bolPermiteAssinaturaCertificado=true;
      }

      $objAssinaturaDTO = new AssinaturaDTO();
      $objAssinaturaDTO->setStrStaFormaAutenticacao($_POST['hdnFormaAutenticacao']);
      
      if (!isset($_POST['hdnFlagAssinatura'])){
        $objAssinaturaDTO->setNumIdOrgaoUsuario(SessaoSEI::getInstance()->getNumIdOrgaoUsuario());
      }else{
        $objAssinaturaDTO->setNumIdOrgaoUsuario($_POST['selOrgao']);
      }

      if (!isset($_POST['hdnFlagAssinatura'])){
        $objAssinaturaDTO->setNumIdContextoUsuario(SessaoSEI::getInstance()->getNumIdContextoUsuario());
      }else{
        $objAssinaturaDTO->setNumIdContextoUsuario($_POST['selContexto']);
      }
      
      $objAssinaturaDTO->setNumIdUsuario($_POST['hdnIdUsuario']);
      $objAssinaturaDTO->setStrSenhaUsuario($_POST['pwdSenha']);
      
      //$objAssinaturaDTO->setStrCargoFuncao(PaginaSEI::getInstance()->recuperarCampo('selCargoFuncao'));
      
      $objInfraDadoUsuario = new InfraDadoUsuario(SessaoSEI::getInstance());

      $strChaveDadoUsuarioAssinatura = 'ASSINATURA_CARGO_FUNCAO_'.SessaoSEI::getInstance()->getNumIdUnidadeAtual();

      if (!isset($_POST['selCargoFuncao'])){
        $objAssinaturaDTO->setStrCargoFuncao($objInfraDadoUsuario->getValor($strChaveDadoUsuarioAssinatura));
      }else{
        $objAssinaturaDTO->setStrCargoFuncao($_POST['selCargoFuncao']);

        if ($objAssinaturaDTO->getNumIdUsuario()==SessaoSEI::getInstance()->getNumIdUsuario()) {
          $objInfraDadoUsuario->setValor($strChaveDadoUsuarioAssinatura, $_POST['selCargoFuncao']);
        }
      }

      if ($_POST['hdnFormaAutenticacao'] != null){

        if($_POST['hdnFormaAutenticacao']==AssinaturaRN::$TA_CERTIFICADO_DIGITAL && !$bolPermiteAssinaturaCertificado){
          throw new InfraException('Assinatura por Certificado Digital n�o permitida.');
        } else if($_POST['hdnFormaAutenticacao']==AssinaturaRN::$TA_SENHA && !$bolPermiteAssinaturaLogin){
          throw new InfraException('Assinatura por login n�o permitida.');
        }
        $objAssinaturaDTO->setArrObjDocumentoDTO(InfraArray::gerarArrInfraDTO('DocumentoDTO','IdDocumento',$arrIdDocumentos));
        
        try{

          $objDocumentoRN = new DocumentoRN();
          $arrObjAssinaturaDTO = $objDocumentoRN->assinar($objAssinaturaDTO);
          
          $bolAssinaturaOK = true;

          if ($objAssinaturaDTO->getStrStaFormaAutenticacao() == AssinaturaRN::$TA_CERTIFICADO_DIGITAL) {

            $strJSDocumentosAssinar = '';
            $strJSAssinaturas = '  arrIdsAssinaturas = [];'."\n";

            foreach($arrObjAssinaturaDTO as $dto){

              if ($strJSDocumentosAssinar == ''){
                $strJSDocumentosAssinar .= '  strIdsDocumentosAssinar = "'.$dto->getDblIdDocumento().'='.$dto->getStrProtocoloDocumentoFormatado().'";'."\n";
              }else{
                $strJSDocumentosAssinar .= '  strIdsDocumentosAssinar += ";'.$dto->getDblIdDocumento().'='.$dto->getStrProtocoloDocumentoFormatado().'";'."\n";
              }

              $strJSAssinaturas .= '  arrIdsAssinaturas.push("'.$dto->getDblIdDocumento().':'.$dto->getNumIdAssinatura().'");'."\n";
            }

            $oCodeDownload = 'http://java.com/download/';
            $oJavaVersion = '1.7+';

            $strDivCertificacao = '<br/><br/><br/>';

            $strDivCertificacao .= '<div id="divExibeApplet" style="width:100%; top:0%;">';

            $arrArquivosCache = array('assinador/assinador-3.6.jar',
                                      'assinador/sei-assinador-3.6.jar',
                                      'assinador/bcprov-jdk15-1.45.jar',
                                      'assinador/bcmail-jdk15-1.45.jar',
                                      'assinador/demoiselle-certificate-ca-icpbrasil-1.0.12.jar',
                                      'assinador/demoiselle-certificate-core-1.0.12.jar',
                                      'assinador/demoiselle-certificate-criptography-1.0.12.jar',
                                      'assinador/demoiselle-certificate-signer-1.0.12.jar',
                                      'assinador/log4j-1.2.16.jar',
                                      'assinador/slf4j-api-1.6.1.jar',
                                      'assinador/slf4j-log4j12-1.6.1.jar');

            $strArquivosCache = implode(',', $arrArquivosCache);
            $strVersoesCache = implode(',', array_fill(0, count($arrArquivosCache), 'SEI-'.SEI_VERSAO));

            if (PaginaSEI::getInstance()->isBolNavegadorIE()){
              $strDivCertificacao .= '<object id="assinador" classid = "clsid:8AD9C840-044E-11D1-B3E9-00805F499D93" border="0"
              codebase = "'.$oCodeDownload.'" width = "550" height = "45" align = "center">
              <param name = "archive"    value="'.$strArquivosCache.'"/>
              <param name = "java_version"    value="'.$oJavaVersion.'"/>
              <param name = "code" 			value = "br.jus.trf4.assinador.applet.AssinadorApplet" />
              <param name = "type" 			value = "application/x-java-applet"/>
              <param name = "browser" 		value="MSIE"/>
              <param name = "submit.form" 	value="true"/>
              <param name = "nome.form" 		value=""/>
              <param name = "cache_option"  value="browser" />
              <param name = "cache_archive" value="'.$strArquivosCache.'" />
              <param name = "cache_version" 	value="'.$strVersoesCache.'" />
              <param name = "url.upload" 		value=""/> <!-- vazio para n�o fazer upload -->
              <param name = "url.download"	value=""/>
              <param name = "url.service"	    value="'.ConfiguracaoSEI::getInstance()->getValor('SEI','URL').'/controlador_ws.php?servico=assinador"/>
              <param name = "url.service.up"  value="'.ConfiguracaoSEI::getInstance()->getValor('SEI','URL').'/controlador_ws.php?servico=assinador"/>
              <param name = "service.provider" value="br.jus.trf4.assinador.sei.SEIClient"/>
              <param name = "standalone" 		value="false"/>
              </object>';
            } else if (PaginaSEI::getInstance()->isBolNavegadorFirefox()){
              $strDivCertificacao .= '<embed id="assinador" CODE = "br.jus.trf4.assinador.applet.AssinadorApplet"
              type="application/x-java-applet"
              java_version="'.$oJavaVersion.'"
              pluginspage="'.$oCodeDownload.'"
              width = "550" height = "45" align = "center"
              mayscript = "mayscript"
              browser 		="MOZZ"
              submit.form 	="true"
              nome.form 		=""
              cache_option  ="browser"
              cache_archive 	="'.$strArquivosCache.'"
              cache_version 	="'.$strVersoesCache.'"
              url.upload		=""
              url.download	=""
              url.service		="'.ConfiguracaoSEI::getInstance()->getValor('SEI','URL').'/controlador_ws.php?servico=assinador"
              url.service.up	="'.ConfiguracaoSEI::getInstance()->getValor('SEI','URL').'/controlador_ws.php?servico=assinador"
              service.provider="br.jus.trf4.assinador.sei.SEIClient">
              </embed>';
            } else {
              throw new InfraException('Este navegador n�o suporta o plugin de assinatura digital do SEI.');
            }
            $strDivCertificacao .=  '</div>'."\n";

          }
        }catch(Exception $e){
          PaginaSEI::getInstance()->processarExcecao($e, true);
        }
      }
      
      break;
      
    default:
      throw new InfraException("A��o '".$_GET['acao']."' n�o reconhecida.");
  }

  $arrComandos = array();
  

  if ($numRegistros) {

    if (PaginaSEI::getInstance()->isBolAndroid() && PaginaSEI::getInstance()->isBolNavegadorFirefox() && $bolPermiteAssinaturaLogin ) {
      $arrComandos[] = '<button type="button" accesskey="A" onclick="assinarSenha();" id="btnAssinar" name="btnAssinar" value="Assinar" class="infraButton">&nbsp;<span class="infraTeclaAtalho">A</span>ssinar&nbsp;</button>';
    } else if ($bolPermiteAssinaturaCertificado){
      $arrComandos[] = '<button type="button" accesskey="A" onclick="assinarCertificadoDigital();" id="btnAssinar" name="btnAssinar" value="Assinar" class="infraButton" style="visibility:hidden">&nbsp;<span class="infraTeclaAtalho">A</span>ssinar&nbsp;</button>';
    }
  }

  if (!isset($_POST['hdnIdUsuario'])){
    $strIdUsuario = SessaoSEI::getInstance()->getNumIdUsuario();
    $strNomeUsuario = SessaoSEI::getInstance()->getStrNomeUsuario();
  }else{
    $strIdUsuario = $_POST['hdnIdUsuario'];
    $strNomeUsuario = $_POST['txtUsuario'];
  }

  if ($bolAssinaturaOK){
    $strDisplayAutenticacao = 'display:none;';
  }else{
    $strDisplayAutenticacao = '';
  }

  $strDisplayContexto = '';
  $objContextoDTO = new ContextoDTO();
  $objContextoDTO->setNumIdOrgao($objAssinaturaDTO->getNumIdOrgaoUsuario());

  $objContextoRN = new ContextoRN();
  if ($objContextoRN->contar($objContextoDTO) == 0){
    $strDisplayContexto = 'display:none;';  
  }

  $strLinkAjaxUsuarios = SessaoSEI::getInstance()->assinarLink('controlador_ajax.php?acao_ajax=usuario_assinatura_auto_completar');
  $strItensSelOrgaos = OrgaoINT::montarSelectSiglaRI1358('null','&nbsp;',$objAssinaturaDTO->getNumIdOrgaoUsuario());
  $strLinkAjaxContexto = SessaoSEI::getInstance()->assinarLink('controlador_ajax.php?acao_ajax=contexto_carregar_nome');
  $strItensSelContextos = ContextoINT::montarSelectNome('null','&nbsp;',$objAssinaturaDTO->getNumIdContextoUsuario(),$objAssinaturaDTO->getNumIdOrgaoUsuario());
  $strItensSelCargoFuncao = AssinanteINT::montarSelectCargoFuncaoUnidadeUsuarioRI1344('null','&nbsp;', $objAssinaturaDTO->getStrCargoFuncao(), $strIdUsuario);
  $strLinkAjaxCargoFuncao = SessaoSEI::getInstance()->assinarLink('controlador_ajax.php?acao_ajax=assinante_carregar_cargo_funcao');

  $strIdDocumentos = implode(',',$arrIdDocumentos);
  $strHashDocumentos = md5($strIdDocumentos);


}catch(Exception $e){ 
  PaginaSEI::getInstance()->processarExcecao($e);
}

PaginaSEI::getInstance()->montarDocType();
PaginaSEI::getInstance()->abrirHtml();
PaginaSEI::getInstance()->abrirHead();
PaginaSEI::getInstance()->montarMeta();
PaginaSEI::getInstance()->montarTitle(PaginaSEI::getInstance()->getStrNomeSistema().' - '.$strTitulo);
PaginaSEI::getInstance()->montarStyle();
PaginaSEI::getInstance()->abrirStyle();
?>

#lblOrgao {position:absolute;left:0%;top:0%;}
#selOrgao {position:absolute;left:0%;top:40%;width:40%;}

#divContexto {<?=$strDisplayContexto?>}
#lblContexto {position:absolute;left:0%;top:0%;}
#selContexto {position:absolute;left:0%;top:40%;width:40%;}

#lblUsuario {position:absolute;left:0%;top:0%;}
#txtUsuario {position:absolute;left:0%;top:40%;width:60%;}

#divAutenticacao {<?=$strDisplayAutenticacao?>}
#pwdSenha {width:15%;}

#lblCargoFuncao {position:absolute;left:0%;top:0%;}
#selCargoFuncao {position:absolute;left:0%;top:40%;width:99%;}

#lblOu {<?=((PaginaSEI::getInstance()->isBolIpad() || PaginaSEI::getInstance()->isBolAndroid())?'visibility:hidden;':'')?>}
#lblCertificadoDigital {<?=((PaginaSEI::getInstance()->isBolIpad() || PaginaSEI::getInstance()->isBolAndroid())?'visibility:hidden;':'')?>}
#divAjudaAssinaturaDigital {display:inline;<?=((PaginaSEI::getInstance()->isBolIpad() || PaginaSEI::getInstance()->isBolAndroid())?'visibility:hidden;':'')?>}
#ancAjudaAssinaturaDigital {position:absolute;}

<?
PaginaSEI::getInstance()->fecharStyle();
PaginaSEI::getInstance()->montarJavaScript();
PaginaSEI::getInstance()->abrirJavaScript();
?>

//<script>

var objAjaxContexto = null;
var objAutoCompletarUsuario = null;
var objAjaxCargoFuncao = null;
var bolAssinandoSenha = false;

<?if ($objAssinaturaDTO->getStrStaFormaAutenticacao() == AssinaturaRN::$TA_CERTIFICADO_DIGITAL) {?>

function verificarQuantidadeCertificados(){
  if (document.getElementById("assinador").getNumCertificados() == 1){
  assinarCertificadoDigital();
  }else if (document.getElementById("assinador").getNumCertificados() > 1){  
    document.getElementById('btnAssinar').style.visibility = 'visible';    
  }      
}

function assinarCertificadoDigital(){
  applet = document.getElementById("assinador");
	var sucesso = false;
  document.getElementById('btnAssinar').style.visibility = 'hidden';

  <?=$strJSDocumentosAssinar?>

  <?=$strJSAssinaturas?>

  //setar propriedades para o assinador. isso permite que outros sistemas 
  //possam usar o assinador passando os seus parametros
  properties = "strIdsAssinaturas=";        
  for(var i=0;i < arrIdsAssinaturas.length;i++){
    if (i>0){
      properties += "|";
    }
    properties += arrIdsAssinaturas[i];
  }  
        
  applet.jsSetPropertiesStr(properties);
	sucesso = applet.jsSignDocsListStr(strIdsDocumentosAssinar);
          
}
// funcao chamada pelo applet ap�s este ser carregado
function onFinishApplet(){   
  infraOcultarAviso();      
  verificarQuantidadeCertificados();     
}

// funcao chamada pelo applet se retornar um erro tipo Exception
function onErrorApplet(erro){
  //alert(erro);
}

//funcao chamada pelo applet depois de assinar e antes de fazer o submit 
function afterSign() {
  finalizar();
}

<?}?>

function inicializar(){

  <?if ($numRegistros==0){?>
    alert('Nenhum documento informado.');
    return;
  <?}?>

  <?if ($bolDocumentoNaoEncontrado){?>
    alert('Documento n�o encontrado.');
    return;
  <?}?>

  //se realizou assinatura
  <?if ($bolAssinaturaOK){ ?>
  
    <?if ($objAssinaturaDTO->getStrStaFormaAutenticacao() == AssinaturaRN::$TA_CERTIFICADO_DIGITAL) {?>
        infraExibirAviso(false);
    <?} else {?>
       finalizar();
    <?}?>

    return;

  <?}else{?>
  
    if (document.getElementById('selCargoFuncao').options.length==2){
      document.getElementById('selCargoFuncao').options[1].selected = true;
    }

    objAjaxContexto = new infraAjaxMontarSelect('selContexto','<?=$strLinkAjaxContexto?>');
    objAjaxContexto.mostrarAviso = false;
    objAjaxContexto.prepararExecucao = function(){
      return 'id_orgao=' + document.getElementById('selOrgao').value;
    }
    objAjaxContexto.processarResultado = function(numItens){
      if (numItens){
        document.getElementById('divContexto').style.display = 'block';
      }else{
        document.getElementById('divContexto').style.display = 'none';
      }
    }

    objAjaxCargoFuncao = new infraAjaxMontarSelect('selCargoFuncao','<?=$strLinkAjaxCargoFuncao?>');
    //objAjaxCargoFuncao.mostrarAviso = true;
    //objAjaxCargoFuncao.tempoAviso = 2000;
    objAjaxCargoFuncao.prepararExecucao = function(){

      if (document.getElementById('hdnIdUsuario').value==''){
        return false;
      }

      return 'id_usuario=' + document.getElementById('hdnIdUsuario').value;
    }

    objAutoCompletarUsuario = new infraAjaxAutoCompletar('hdnIdUsuario','txtUsuario','<?=$strLinkAjaxUsuarios?>');
    //objAutoCompletarUsuario.maiusculas = true;
    //objAutoCompletarUsuario.mostrarAviso = true;
    //objAutoCompletarUsuario.tempoAviso = 1000;
    //objAutoCompletarUsuario.tamanhoMinimo = 3;
    objAutoCompletarUsuario.limparCampo = true;
    //objAutoCompletarUsuario.bolExecucaoAutomatica = false;

    objAutoCompletarUsuario.prepararExecucao = function(){

      if (!infraSelectSelecionado(document.getElementById('selOrgao'))){
        alert('Selecione um �rg�o.');
        document.getElementById('selOrgao').focus();
        return false;
      }

      return 'id_orgao=' + document.getElementById('selOrgao').value + '&palavras_pesquisa='+document.getElementById('txtUsuario').value + '&inativos=0';
    };

    objAutoCompletarUsuario.processarResultado = function(id,descricao,complemento){
      if (id!=''){
        document.getElementById('hdnIdUsuario').value = id;
        document.getElementById('txtUsuario').value = descricao;
        objAjaxCargoFuncao.executar();
        window.status='Finalizado.';
      }
    }

    //infraSelecionarCampo(document.getElementById('txtUsuario'));

    document.getElementById('pwdSenha').focus();
  <?}?>
}

function OnSubmitForm() {

  if (!infraSelectSelecionado(document.getElementById('selOrgao'))){
    alert('Selecione um �rg�o.');
    document.getElementById('selOrgao').focus();
    return false;
  }

  if (document.getElementById('selContexto').options.length > 0 &&  !infraSelectSelecionado(document.getElementById('selContexto'))){
    alert('Selecione um Contexto.');
    document.getElementById('selContexto').focus();
    return false;
  }
  
  if (infraTrim(document.getElementById('hdnIdUsuario').value)==''){
    alert('Informe um Assinante.');
    document.getElementById('txtUsuario').focus();
    return false;
  }

  if (!infraSelectSelecionado(document.getElementById('selCargoFuncao'))){
    alert('Selecione um Cargo/Fun��o.');
    document.getElementById('selCargoFuncao').focus();
    return false;
  }
  
  if ('<?=$numRegistros?>'=='0'){
    alert('Nenhum documento informado para assinatura.');
    return false;
  }

  return true;
}

function trocarOrgaoUsuario(){
  objAutoCompletarUsuario.limpar();
  objAjaxContexto.executar();
  objAjaxCargoFuncao.executar();
}
<? if($bolPermiteAssinaturaLogin) { ?>
function assinarSenha(){
  if (infraTrim(document.getElementById('pwdSenha').value)==''){
    alert('Senha n�o informada.');
  }else{
    document.getElementById('hdnFormaAutenticacao').value = '<?=AssinaturaRN::$TA_SENHA?>';
    if (OnSubmitForm()){
      infraExibirAviso(false);
      document.getElementById('frmAssinaturas').submit();
      return true;
    }
  }
  return false;
}

function tratarSenha(ev){
  if (!bolAssinandoSenha && infraGetCodigoTecla(ev)==13){
    bolAssinandoSenha = true;
    if (!assinarSenha()){
	    bolAssinandoSenha = false;
    }
  }
}
<? } ?>
<? if($bolPermiteAssinaturaCertificado) { ?>
function tratarCertificadoDigital(){
  document.getElementById('hdnFormaAutenticacao').value = '<?=AssinaturaRN::$TA_CERTIFICADO_DIGITAL?>';
  if (OnSubmitForm()){
    infraExibirAviso(false);
    document.getElementById('frmAssinaturas').submit();
  }
}
<? } ?>

function finalizar(){

  //se realizou assinatura
  <?if ($bolAssinaturaOK){ ?>

     window.opener.infraFecharJanelaModal();
  
     <? if ($_GET['arvore'] == '1'){ ?>
     
       //atualiza �rvore para mostrar caneta de assinatura
       window.opener.parent.document.getElementById('ifrArvore').src = '<?=SessaoSEI::getInstance()->assinarLink('controlador.php?acao=procedimento_visualizar&acao_origem='.$_GET['acao'].$strParametros.'&montar_visualizacao=1')?>';
       
     <?}else if($_GET['acao_retorno']=='bloco_navegar'){?>
        window.opener.processarDocumento(window.opener.idatual);
        window.opener.objAjaxAssinaturas.executar();
     <?}else if($_GET['acao_retorno']=='editor_montar'){?>
        window.opener.atualizarArvore(true);
     <?} else {?>
       //atualiza telas de blocos e protocolos de bloco
       window.opener.location.reload();
       
     <?}?>

     window.close();

  <?}?>
}

//</script>
<?
PaginaSEI::getInstance()->fecharJavaScript();
PaginaSEI::getInstance()->fecharHead();
PaginaSEI::getInstance()->abrirBody($strTitulo,'onload="inicializar();"');
?>

<form id="frmAssinaturas" method="post" onsubmit="return OnSubmitForm();" action="<?=SessaoSEI::getInstance()->assinarLink('controlador.php?acao='.$_GET['acao'].'&acao_origem='.$_GET['acao'].'&acao_retorno='.PaginaSEI::getInstance()->getAcaoRetorno().'&hash_documentos='.$strHashDocumentos.$strParametros)?>">
  
	<?
	//PaginaSEI::getInstance()->montarBarraLocalizacao($strTitulo);
	PaginaSEI::getInstance()->montarBarraComandosSuperior($arrComandos);
	//PaginaSEI::getInstance()->montarAreaValidacao();
	if ($numRegistros > 0){
  ?>
   

    <div id="divOrgao" class="infraAreaDados" style="height:4.5em;">
      <label id="lblOrgao" for="selOrgao" accesskey="" class="infraLabelObrigatorio">�rg�o do Assinante:</label>
      <select id="selOrgao" name="selOrgao" onchange="trocarOrgaoUsuario();" class="infraSelect" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>">
      <?=$strItensSelOrgaos?>
      </select>
    </div>
    	  
    <div id="divContexto" class="infraAreaDados" style="height:4.5em;">
      <label id="lblContexto" for="selContexto" accesskey=""  class="infraLabelObrigatorio">Contexto do Assinante:</label>
      <select id="selContexto" name="selContexto" class="infraSelect" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>">
      <?=$strItensSelContextos?>
      </select>
    </div>
    
    <div id="divUsuario" class="infraAreaDados" style="height:4.5em;">
      <label id="lblUsuario" for="txtUsuario" accesskey="A" class="infraLabelObrigatorio"><span class="infraTeclaAtalho">A</span>ssinante:</label>
      <input type="text" id="txtUsuario" name="txtUsuario" class="infraText" value="<?=$strNomeUsuario?>" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>" />
      <input type="hidden" id="hdnIdUsuario" name="hdnIdUsuario" value="<?=$strIdUsuario?>" />
    </div>  

    <div id="divCargoFuncao" class="infraAreaDados" style="height:4.5em;">
      <label id="lblCargoFuncao" for="selCargoFuncao" accesskey="F" class="infraLabelObrigatorio">Cargo / <span class="infraTeclaAtalho">F</span>un��o:</label>
      <select id="selCargoFuncao" name="selCargoFuncao" class="infraSelect" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>">
      <?=$strItensSelCargoFuncao?>
      </select>
    </div>
    <br />
    <div id="divAutenticacao" class="infraAreaDados" style="height:2.5em;">
      <? if($bolPermiteAssinaturaLogin) { ?>
        <label id="lblSenha" for="pwdSenha" accesskey="" class="infraLabelRadio infraLabelObrigatorio" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>">Senha</label>&nbsp;&nbsp;
    		<input type="password" id="pwdSenha" name="pwdSenha" class="infraText" onkeypress="return tratarSenha(event);" value="" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>" />&nbsp;&nbsp;&nbsp;&nbsp;
      <? }
         if($bolPermiteAssinaturaLogin && $bolPermiteAssinaturaCertificado) { ?>
    		<label id="lblOu" class="infraLabelOpcional" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>">ou</label>&nbsp;&nbsp;&nbsp;
      <? }
         if($bolPermiteAssinaturaCertificado) { ?>
        <label id="lblCertificadoDigital" onclick="tratarCertificadoDigital();" accesskey="" for="optCertificadoDigital" class="infraLabelRadio infraLabelObrigatorio" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>"><?=((!$bolPermiteAssinaturaLogin)?(!$bolAutenticacao?'Assinar com ':'Autenticar com '):'')?>Certificado Digital</label>&nbsp;
        <div id="divAjudaAssinaturaDigital"><a id="ancAjudaAssinaturaDigital" href="<?=SessaoSEI::getInstance()->assinarLink('controlador.php?acao=assinatura_digital_ajuda&acao_origem='.$_GET['acao'])?>" target="janAjudaAssinaturaDigital" title="Instru��es para Configura��o da Assinatura Digital" tabindex="<?=PaginaSEI::getInstance()->getProxTabDados()?>"><img src="<?=PaginaSEI::getInstance()->getDiretorioImagensLocal()?>/sei_informacao.png" class="infraImg" /></a></div>
      <? } ?>
    </div>
            
    <?=$strDivCertificacao?>
	<?
	}
	  //PaginaSEI::getInstance()->fecharAreaDados();
	PaginaSEI::getInstance()->montarAreaDebug();
	//PaginaSEI::getInstance()->montarBarraComandosInferior($arrComandos);
  ?>
  <input type="hidden" id="hdnFormaAutenticacao" name="hdnFormaAutenticacao" value="" />
  <input type="hidden" id="hdnAncora" name="hdnAncora" value="<?=$strAncora?>" />
  <input type="hidden" id="hdnFlagAssinatura" name="hdnFlagAssinatura" value="1" />
  <input type="hidden" id="hdnIdDocumentos" name="hdnIdDocumentos" value="<?=$strIdDocumentos?>" />
</form>
<?
PaginaSEI::getInstance()->fecharBody();
PaginaSEI::getInstance()->fecharHtml();
?>