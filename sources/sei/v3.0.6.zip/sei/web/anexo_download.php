<?
/*
* TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
*
* 24/08/2007 - criado por mga
*
*
* Vers�o do Gerador de C�digo:1.6.1
*/
try {
  require_once dirname(__FILE__).'/SEI.php';
  
  session_start(); 
  
  //////////////////////////////////////////////////////////////////////////////
  InfraDebug::getInstance()->setBolLigado(false);
  InfraDebug::getInstance()->setBolDebugInfra(false);
  InfraDebug::getInstance()->limpar();
  //////////////////////////////////////////////////////////////////////////////
      
  SessaoSEI::getInstance()->validarLink(); 
  
  SessaoSEI::getInstance()->validarPermissao($_GET['acao']);
  
  switch($_GET['acao']) {

    case 'documento_download_anexo':
    case 'procedimento_download_anexo':
    case 'base_conhecimento_download_anexo':
    case 'projeto_download_anexo':
    case 'anexo_download':

      $objAnexoRN = new AnexoRN();
      $objAnexoDTO = new AnexoDTO();
      $objAnexoDTO->retNumIdAnexo();
      $objAnexoDTO->retDblIdProtocolo();
      $objAnexoDTO->retStrNome();
      $objAnexoDTO->retDblIdProtocolo();
      $objAnexoDTO->retDthInclusao();
      $objAnexoDTO->retNumTamanho();
      $objAnexoDTO->retStrHash();

      $objAnexoDTO->setNumIdAnexo($_GET['id_anexo']);

      $objAnexoDTO = $objAnexoRN->consultarRN0736($objAnexoDTO);

      if ($objAnexoDTO == null) {
        throw new InfraException('Anexo n�o encontrado.',null, null, false);
      }

      if ($_GET['acao'] == 'anexo_download' && $objAnexoDTO->getDblIdProtocolo()!=null){
        throw new InfraException('A��o inv�lida para este anexo.');
      }

      if ($_GET['acao'] == 'documento_download_anexo') {

        $objDocumentoDTO = new DocumentoDTO();
        $objDocumentoDTO->retDblIdDocumento();
        $objDocumentoDTO->retNumIdUnidadeGeradoraProtocolo();
        $objDocumentoDTO->retStrStaProtocoloProtocolo();
        $objDocumentoDTO->retStrSinBloqueado();
        $objDocumentoDTO->retStrStaDocumento();
        $objDocumentoDTO->setDblIdDocumento($objAnexoDTO->getDblIdProtocolo());

        $objDocumentoRN = new DocumentoRN();
        $objDocumentoRN->bloquearConsultado($objDocumentoRN->consultarRN0005($objDocumentoDTO));

        $objAuditoriaProtocoloDTO = new AuditoriaProtocoloDTO();
        $objAuditoriaProtocoloDTO->setStrRecurso($_GET['acao']);
        $objAuditoriaProtocoloDTO->setNumIdUsuario(SessaoSEI::getInstance()->getNumIdUsuario());
        $objAuditoriaProtocoloDTO->setDblIdProtocolo($objAnexoDTO->getDblIdProtocolo());
        $objAuditoriaProtocoloDTO->setNumIdAnexo($objAnexoDTO->getNumIdAnexo());
        $objAuditoriaProtocoloDTO->setNumVersao(null);
        $objAuditoriaProtocoloDTO->setDtaAuditoria(InfraData::getStrDataAtual());

        $objAuditoriaProtocoloRN = new AuditoriaProtocoloRN();
        $objAuditoriaProtocoloRN->auditarVisualizacao($objAuditoriaProtocoloDTO);

      } else {
        AuditoriaSEI::getInstance()->auditar($_GET['acao']);
      }

      //vindo de qualquer outro ponto que n�o seja a �rvore e acessando documentos do processo
      if ($_GET['acao_origem'] != 'procedimento_visualizar' && ($_GET['acao'] == 'procedimento_download_anexo' || $_GET['acao'] == 'documento_download_anexo')) {

        //verifica permiss�o de acesso ao documento
        $objPesquisaProtocoloDTO = new PesquisaProtocoloDTO();
        $objPesquisaProtocoloDTO->setStrStaTipo(ProtocoloRN::$TPP_DOCUMENTOS);
        $objPesquisaProtocoloDTO->setStrStaAcesso(ProtocoloRN::$TAP_AUTORIZADO);
        $objPesquisaProtocoloDTO->setDblIdProtocolo($objAnexoDTO->getDblIdProtocolo());

        $objProtocoloRN = new ProtocoloRN();
        $arrObjProtocoloDTO = $objProtocoloRN->pesquisarRN0967($objPesquisaProtocoloDTO);

        if (count($arrObjProtocoloDTO) == 0) {
          header('Location: ' . SessaoSEI::getInstance()->assinarLink('controlador.php?acao=procedimento_trabalhar&id_documento=' . $objAnexoDTO->getDblIdProtocolo()));
          die;
        }
      }

      $strContentDisposition = 'inline';

      if ((isset($_GET['download']) && $_GET['download']=='1')) {

        $strContentDisposition = 'attachment';

      }else if (PaginaSEI::getInstance()->isBolIpad() || PaginaSEI::getInstance()->isBolIphone() || PaginaSEI::getInstance()->isBolAndroid()){

        $arrStrNome = explode(".", $objAnexoDTO->getStrNome());

        if (count($arrStrNome) > 1){
          $strExtensao = str_replace(' ','',InfraString::transformarCaixaBaixa($arrStrNome[count($arrStrNome)-1]));
          if (!in_array($strExtensao, array('htm', 'html', 'png', 'jpg', 'jpeg', 'gif', 'txt'))){
            $strContentDisposition = 'attachment';
          }
        }else{
          $strContentDisposition = 'attachment';
        }
      }

      $numTime = time() + microtime();

      SeiINT::download($objAnexoDTO, null, null, $strContentDisposition);

      $numTime = (time() + microtime()) - $numTime;

      $numKbs = null;

      if ($numTime && $objAnexoDTO->getNumTamanho() > (256 * 1024)){ //s� contabiliza arquivos maiores que 256kb

        try{

          $objVelocidadeTransferenciaDTO = new VelocidadeTransferenciaDTO();
          $objVelocidadeTransferenciaDTO->setNumIdUsuario(SessaoSEI::getInstance()->getNumIdUsuario());
          $objVelocidadeTransferenciaDTO->setNumIdUnidade(SessaoSEI::getInstance()->getNumIdUnidadeAtual());
          $objVelocidadeTransferenciaDTO->setDblVelocidade(round(($objAnexoDTO->getNumTamanho()/1024)/$numTime));

          $objVelocidadeTransferenciaRN = new VelocidadeTransferenciaRN();
          $objVelocidadeTransferenciaRN->contabilizar($objVelocidadeTransferenciaDTO);

        }catch(Exception $e){
          LogSEI::getInstance()->gravar(InfraException::inspecionar($e));
        }
      }
        
      break;
     
    default:
      throw new InfraException("A��o '".$_GET['acao']."' n�o reconhecida.");
  }
  
}catch(Exception $e){
  PaginaSEI::getInstance()->setTipoPagina(InfraPagina::$TIPO_PAGINA_SIMPLES);
  PaginaSEI::getInstance()->processarExcecao($e);
}
?>