<?
  /**
  * TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
  * 30/05/2016 - CRIADO POR cle@trf4.jus.br
  * Documenta��o da API: https://www.zabbix.com/documentation/2.4/manual/api
  * @package infra_php
  */

  require_once 'phpzabbix/ZabbixApi.class.php';
  use ZabbixApi\ZabbixApi;
  
  abstract class InfraZabbix implements InfraIMonitoramento {

    private $objZabbixApi = '';
    
		public function __construct() {
		  $this->abrirConexao();
		}
		
		private function abrirConexao() {
		  $this->objZabbixApi = new ZabbixApi($this->getServidor(), $this->getUsuario(), $this->getSenha());
		}

		public function listarHosts($strNome='', $strIdGrupo='', $strOrdem='', $strLimite='') {
		  $arrCriterios = $this->montarArrayCriterios('item', $strOrdem, $strLimite, $strNome, $strIdGrupo, '', '');
		  $arrResultado = $this->objZabbixApi->hostGet($arrCriterios);
		  return $this->montarArrayResultadoFinal($arrResultado);
		}
		
		public function listarGrupos($strNome='', $strIdGrupo='', $strOrdem='', $strLimite='') {
		  $arrCriterios = $this->montarArrayCriterios('grupo', $strOrdem, $strLimite, $strNome, $strIdGrupo, '', '');
		  $arrResultado = $this->objZabbixApi->hostgroupGet($arrCriterios);		  
		  return $this->montarArrayResultadoFinal($arrResultado);
		}
		
		public function listarAlertas($strMensagem='', $strDestinatario='', $strOrdem='', $strLimite='') {
		  $arrCriterios = $this->montarArrayCriterios('alerta', $strOrdem, $strLimite, '', '', $strMensagem, $strDestinatario);
		  $arrResultado = $this->objZabbixApi->alertGet($arrCriterios);		  
		  return $this->montarArrayResultadoFinal($arrResultado);
		}
		
		private function montarArrayCriterios($strTipo, $strOrdem='', $strLimite='', $strNome='', $strIdGrupo='', $strMensagem='', $strDestinatario='', $strIdsHost='') {
		  $arrCriterios = array('output'=>'extend');
		  
		  if ($strOrdem != '') {
		    if (($strTipo == 'item') || ($strTipo == 'grupo')) {
  		    $arrCriterios['sortfield'] = 'name';
		    } elseif ($strTipo == 'alerta') {
		      $arrCriterios['sortfield'] = 'alertid';
		    }
		    $arrCriterios['sortorder'] = $strOrdem;
		  }
		  if ($strLimite != '') {		    
		    $arrCriterios['limit'] = $strLimite;
		  }
		  if ($strNome != '') {
  		  $arrCriterios['search'] = array('name'=>$strNome);
		  }
		  if ($strIdGrupo != '') {
  		  $arrCriterios['groupids'] = $strIdGrupo;
		  }
		  if ($strMensagem != '') {
  		  $arrCriterios['search'] = array('message'=>$strMensagem);
		  }
		  if ($strDestinatario != '') {
  		  $arrCriterios['sendto'] = $strDestinatario;
		  }
		  if ($strIdsHost != '') {
  		  $arrCriterios['hostids'] = $strIdsHost;
		  }
		  
		  return $arrCriterios;
		}
		
		private function montarArrayResultadoFinal($arrResultado) {
		  $arrResultadoFinal = array();
		  
		  if (count($arrResultado) > 0) {
  		  for ($i=0; $i<count($arrResultado); $i++) {
  		    if (isset($arrResultado[$i]->hostid)) {
    		    $arrResultadoFinal[$i]['id_item'] = $arrResultado[$i]->hostid;
  		    }
  		    if (isset($arrResultado[$i]->groupid)) {
    		    $arrResultadoFinal[$i]['id_grupo'] = $arrResultado[$i]->groupid;  		    
  		    }
  		    if (isset($arrResultado[$i]->host)) {
    		    $arrResultadoFinal[$i]['item'] = $arrResultado[$i]->host;
  		    }
  		    if (isset($arrResultado[$i]->name)) {
    		    $arrResultadoFinal[$i]['nome'] = $arrResultado[$i]->name;  		    
  		    }  		    
  		    if (isset($arrResultado[$i]->status)) {
    		    $arrResultadoFinal[$i]['situacao'] = $arrResultado[$i]->status;
  		    }
  		    if (isset($arrResultado[$i]->message)) {
    		    $arrResultadoFinal[$i]['mensagem'] = $arrResultado[$i]->message;  		    
  		    }  		    
  		  }
		  }
		  
		  return $arrResultadoFinal;
		}
		
		public function __destruct() {
		  $this->objZabbixApi->userLogout();
		}
		
  }
?>