<?
/**
* TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
*
* 07/08/2009 - criado por mga
*
* Vers�o do Gerador de C�digo: 1.27.1
*
* Vers�o no CVS: $Id$
*/

//require_once 'Infra.php';

class InfraSequenciaBD extends InfraBD {

  public function __construct(InfraIBanco $objInfraIBanco){
  	 parent::__construct($objInfraIBanco);
  }

}
?>