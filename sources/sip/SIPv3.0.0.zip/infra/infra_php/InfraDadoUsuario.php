<?
/**
 * TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
 * 
 * 30/05/2006 - criado por MGA
 *
 * @package infra_php
 */

/*
CREATE TABLE infra_dado_usuario (
	id_usuario            integer  NOT NULL ,
	nome                  varchar(50)  NOT NULL ,
	valor                 varchar(4000)  NULL 
);

ALTER TABLE infra_dado_usuario ADD CONSTRAINT  pk_infra_dado_usuario PRIMARY KEY (id_usuario  ASC,nome  ASC);

*/
 		
class InfraDadoUsuario extends InfraRN {
	private $objInfraIBanco = null;
	private $objInfraSessao = null;
	
	public function __construct(InfraSessao $objInfraSessao){
	  $this->objInfraSessao = $objInfraSessao;
	  $this->objInfraIBanco = $objInfraSessao->getObjInfraIBanco();	
	}
	
  protected function inicializarObjInfraIBanco(){
    return $this->objInfraIBanco;
  }
  
  protected function getValorConectado($strNome) {

      if (InfraDebug::isBolProcessar()) {
        InfraDebug::getInstance()->gravarInfra('[InfraDadoUsuario->getStrValor] ' . $strNome);
      }

  	  if ($this->objInfraSessao->getNumIdUsuario()==null){
  	    throw new InfraException('Usu�rio n�o configurado na sess�o.');
  	  }
  	  	
  	  $sql = '';
			$sql .= ' SELECT valor';
			$sql .= ' FROM infra_dado_usuario ';
			$sql .= ' WHERE nome='.$this->objInfraIBanco->formatarGravacaoStr($strNome);
			$sql .= ' AND id_usuario='.$this->objInfraIBanco->formatarGravacaoNum($this->objInfraSessao->getNumIdUsuario());

			//echo $sql.'<br>';
					
			$rs = $this->objInfraIBanco->consultarSql($sql);

			if (count($rs)==0) {
				return null;
			}

			return $rs[0]['valor'];
  }  

  protected function setValorControlado($strNome,$strValor) {

      if (InfraDebug::isBolProcessar()) {
        InfraDebug::getInstance()->gravarInfra('[InfraDadoUsuario->setStrValor] ' . $strNome . ': ' . $strValor);
      }

 	    if ($this->objInfraSessao->getNumIdUsuario()==null){
 	      throw new InfraException('Usu�rio n�o configurado na sess�o.');
 	    }
 	    
 	    if (strlen($strNome)>50){
 	      throw new InfraException('Nome do Dado do Usu�rio possui tamanho superior a 50 caracteres.');
 	    }
 	    
 	    if (strlen($strValor)>4000){
 	      throw new InfraException('Valor do Dado do Usu�rio possui tamanho superior a 4000 caracteres.');
 	    }
    
			if (!$this->isSetValor($strNome)){
	  	  $sql = '';
    	  $sql .= ' INSERT INTO infra_dado_usuario (id_usuario, nome, valor)';
    	  $sql .= ' VALUES ';
    	  $sql .= ' ('.$this->objInfraIBanco->formatarGravacaoNum($this->objInfraSessao->getNumIdUsuario()).','.$this->objInfraIBanco->formatarGravacaoStr($strNome).','.$this->objInfraIBanco->formatarGravacaoStr($strValor).')';
  			//echo $sql.'<br>';
			}else{
    	  $sql = '';
    	  $sql .= ' UPDATE infra_dado_usuario ';
    	  $sql .= ' SET valor='.$this->objInfraIBanco->formatarGravacaoStr($strValor);
    	  $sql .= ' WHERE nome='.$this->objInfraIBanco->formatarGravacaoStr($strNome);
    	  $sql .= ' AND id_usuario='.$this->objInfraIBanco->formatarGravacaoNum($this->objInfraSessao->getNumIdUsuario());
  			//echo $sql.'<br>';
			}
			
  	  $ret = $this->objInfraIBanco->executarSql($sql);
			
			return $ret;
  }  
  
  protected function isSetValorConectado($strNome) {

      if (InfraDebug::isBolProcessar()) {
        InfraDebug::getInstance()->gravarInfra('[InfraDadoUsuario->isSetStrValor] ' . $strNome);
      }

  	  if ($this->objInfraSessao->getNumIdUsuario()==null){
  	    throw new InfraException('Usu�rio n�o configurado na sess�o.');
  	  }
  	
  	  $sql = '';
			$sql .= ' SELECT valor';
			$sql .= ' FROM infra_dado_usuario ';
			$sql .= ' WHERE nome='.$this->objInfraIBanco->formatarGravacaoStr($strNome);
			$sql .= ' AND id_usuario='.$this->objInfraIBanco->formatarGravacaoNum($this->objInfraSessao->getNumIdUsuario());
			//echo $sql.'<br>';

			$rs = $this->objInfraIBanco->consultarSql($sql);

			if (count($rs)==0) {
				return false;
			}

			return true;
  }
  
  protected function removerValorControlado($strNome){
    if ($this->isSetValor($strNome)){
      $sql = '';
      $sql .= ' DELETE FROM infra_dado_usuario ';
      $sql .= ' WHERE nome='.$this->objInfraIBanco->formatarGravacaoStr($strNome);
      $sql .= ' AND id_usuario='.$this->objInfraIBanco->formatarGravacaoNum($this->objInfraSessao->getNumIdUsuario());
      //echo $sql.'<br>';
      
      $rs = $this->objInfraIBanco->executarSql($sql);
    }
  }
  
  protected function removerValoresUsuarioControlado(){
		$sql = '';
		$sql .= ' DELETE FROM infra_dado_usuario ';
		$sql .= ' WHERE id_usuario='.$this->objInfraIBanco->formatarGravacaoNum($this->objInfraSessao->getNumIdUsuario());
		//echo $sql.'<br>';

		$rs = $this->objInfraIBanco->executarSql($sql);
  }
}
?>