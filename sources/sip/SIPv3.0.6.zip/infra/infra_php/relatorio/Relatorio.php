<?
require_once 'Infra.php';
infraAdicionarPath(dirname(__FILE__));
?>